package customloginapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomloginapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomloginapplicationApplication.class, args);
	}

}
